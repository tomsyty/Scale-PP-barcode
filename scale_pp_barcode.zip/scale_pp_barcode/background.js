class CustomError extends Error {
  constructor(message, options) {
    super(message, options);
		this.name = 'customError';
  }
}

const DOWNLOAD_FAILED_MESSAGE = 'Błąd podczas pobierania etykiety, szczegóły (oryginalna treść wiadomości):';
const REMOVE_FAILED_MESSAGE = 'Błąd podczas usuwania etykiety, szczegóły (oryginalna treść wiadomości):';
const UPDATE_CHECK_FAILED_MESSAGE = 'Nie udało się sprawdzić aktualizacji rozszerzenia, szczegóły (oryginalna treść wiadomości):';
const UPDATE_CHECK_STATUS_CODE_NOT_200 = 'brak pliku z informacją o aktualizacji';

(function main() {
  console.log('Załadowano rozszerzenie');
})();	

fetch('https:/raw.githubusercontent.com/tomsyty/Scale-PP-barcode/main/current-version').then(response => {
	if (response.status !== 200) throw new CustomError(UPDATE_CHECK_STATUS_CODE_NOT_200);
	return response.text();
}).then(currentVersion => {
	if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
		chrome.permissions.contains({ permissions: ['notifications'] }).then(granted => {
			if (granted) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({url: 'https://github.com/tomsyty/Scale-PP-barcode'});
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				console.log('brak uprawnień do powiadomień');
			}
		});
	}
}).catch(error => console.log(`${UPDATE_CHECK_FAILED_MESSAGE} ${error.message}`));

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	const action = request.action;
  switch (action) {
    case 'downloadLabel': {
      let downloadItemId = 0;
			function downloadEvent(downloadItem) {
				if (downloadItemId === 0) {
					chrome.downloads.search({
						state: 'in_progress',
						mime: 'application/pdf',
						finalUrlRegex: '^blob:https://allegro.pl|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
						limit: 1,
						orderBy: ["-startTime"],
					}).then(downloadSearchResult => {
						if (downloadSearchResult.length) {
							downloadItemId = downloadSearchResult[0].id;     
						}
					});
				}
				if (downloadItem.state !== undefined && downloadItem.state.current === 'complete' && downloadItem.id === downloadItemId) {
					chrome.downloads.onChanged.removeListener(downloadEvent);
					chrome.downloads.search({
						state: 'complete',
						exists: true,
						mime: 'application/pdf',
						finalUrlRegex: '^blob:https://allegro.pl|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
						limit: 1,
						id: downloadItemId
					}).then(downloadSearchResult => {
						if (downloadSearchResult.length) {
							sendResponse({ filename: 'downloads/' + downloadSearchResult[0].filename.slice(downloadSearchResult[0].filename.lastIndexOf('\\') + 1), id: downloadSearchResult[0].id });
						}
					}).catch(error => {
            console.log(`${DOWNLOAD_FAILED_MESSAGE} ${error.message}`);
						throw new CustomError(`${DOWNLOAD_FAILED_MESSAGE} ${error.message}`);
					});
				}
			}		
			chrome.downloads.onChanged.addListener(downloadEvent);
			break;
    }
    case 'removeLabel': {
      chrome.downloads.removeFile(request.downloadItemId).then(() => {
        sendResponse({ status: 'ok' });
      }).catch(error => {
        console.log(`${REMOVE_FAILED_MESSAGE} ${error.message}`);
        throw new CustomError(`${REMOVE_FAILED_MESSAGE} ${error.message}`);
      });
      break;
    }
  }
  return true;
});