const DOWNLOAD_FAILED_MESSAGE = 'Błąd podczas pobierania etykiety.';
const REMOVE_FAILED_MESSAGE = 'Błąd podczas usuwania etykiety.';

(function main() {
  console.log('Załadowano rozszerzenie');

	(async () => {
		for (const contentScript of chrome.runtime.getManifest().content_scripts) {
			for (const tab of await chrome.tabs.query({ url: contentScript.matches })) {
				try {
					chrome.scripting.executeScript({
						target: { tabId: tab.id },
						files: ['content_script.js']
					});
					console.log('odświeżono skrypty na otwartych stronach.');					
				} catch (error) {
					showMessageFromBackground('Błąd! Nie udało się odświeżyć skryptów.');
				}
			}
		}
	})();
})();	

async function removeFile(file) {
	return new Promise((resolve, reject) => {
		chrome.downloads.removeFile(file, () => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(true);
		});
	});
}

(async function checkUpdate() {
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/Scale-PP-barcode/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/Scale-PP-barcode' });
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
		} else {
			console.log(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error.message}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/Scale-PP-barcode' });
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true });
			} else {
				console.log(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('brak pliku z informacją o aktualizacji');
	}
})();

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	const action = request.action;
  switch (action) {
    case 'downloadLabel': {
			let downloadItemId = 0;
			function downloadEvent(downloadItem) {
				if (downloadItemId === 0) {
					chrome.downloads.search({
						state: 'in_progress',
						mime: 'application/pdf',
						finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
						limit: 1,
						orderBy: ["-startTime"],
					}).then(downloadSearchResult => {
						if (downloadSearchResult.length) {
							downloadItemId = downloadSearchResult[0].id;     
						}
					});
				}
				if (downloadItem.state !== undefined && downloadItem.state.current === 'complete' && downloadItem.id === downloadItemId) {
					chrome.downloads.onChanged.removeListener(downloadEvent);
					chrome.downloads.search({
						state: 'complete',
						exists: true,
						mime: 'application/pdf',
						finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
						limit: 1,
						id: downloadItemId
					}).then(downloadSearchResult => {
						if (downloadSearchResult.length) {
							sendResponse({ success: true, result: { filename: 'downloads/' + downloadSearchResult[0].filename.slice(downloadSearchResult[0].filename.lastIndexOf('\\') + 1), id: downloadSearchResult[0].id } });
						}
					}).catch(error => {
						console.log(`${DOWNLOAD_FAILED_MESSAGE} ${error.message}`);
						sendResponse({ success: false, result: `${DOWNLOAD_FAILED_MESSAGE} ${error.message}` });
					});
				}
			}		
			chrome.downloads.onChanged.addListener(downloadEvent);
			break;
		}
		case 'removeLabel': {
			chrome.downloads.removeFile(request.downloadItemId).then(() => {
				sendResponse({ success: true });
			}).catch(error => {
				console.log(`${REMOVE_FAILED_MESSAGE} ${error.message}`);
				sendResponse({ success: false, result: `${REMOVE_FAILED_MESSAGE} ${error.message}` });
			});
			break;
		}
	}
	return true		
});

async function showMessageFromBackground(message) {
  let tab;
	let response;
  try {
    tab = await getCurrentTab();
  } catch (error) {
    console.log(error);
  }

  if (tab !== undefined) {
    try {
      response = await sendMessage(tab.id, { action: 'toast', message: message });
			if (!response.success) throw new Error(response.result);
    } catch (error) {
      console.log(error instanceof Error ? error.message : error);
      const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
        chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: `Błąd rozszerzenia ${chrome.runtime.getManifest().name}`, message: message });
      }
    }
  } else {
    if (message.startsWith('Błąd!')) {
      const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
      if (notificationsAllowed) {
        chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: `Błąd rozszerzenia ${chrome.runtime.getManifest().name}`, message: message });
      }
    }
  }
  return Promise.resolve(true);
}