if (document.getElementById('pdfLibScript') === null) {
  var s = document.createElement('script');
  s.id = 'pdfLibScript';
  s.src = chrome.runtime.getURL('pdf-lib.js');
  (document.head||document.documentElement).appendChild(s);
  s.onload = function() {
    s.remove();
  };
}

async function sendMessage(data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(data, (response) => {
			chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
		});
	});
}

window.addEventListener('load', () => {
  console.log('Załadowano skrypt Scale PP barcode'); 
  let previousUrl = '';
  let observer;
  const urlObserver = new MutationObserver(() => {
    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
      if (window.location.href.search(/https:\/\/salescenter\.allegro\.com(?:\.allegrosandbox\.pl|)\/ship-with-allegro\/swa\/create-shipment-status/) === 0) {
        (async function findDownloadButton() {
          let downloadButton = Array.from(document.querySelectorAll('button:enabled')).find(element => element.textContent === 'Pobierz etykietę');
          if (downloadButton !== undefined) {
            const shippingMethodCell = Array.from(document.querySelectorAll('th')).find(element => element.innerText === 'Metoda dostawy');
            if (shippingMethodCell !== undefined) {
              const shippingMethod = shippingMethodCell?.parentNode?.parentNode?.nextElementSibling?.firstChild?.childNodes?.[shippingMethodCell.cellIndex]?.innerText;
              if (['Mini Przesyłka', 'Allegro Mini Przesyłka', 'Allegro MiniPrzesyłka', 'Allegro Przesyłka polecona', 'Przesyłka Polecona'].indexOf(shippingMethod) === -1) return;
              downloadButton.addEventListener('click', downloadLabelButtonClick);
              downloadButton.style.backgroundColor = 'lightgreen';
            }
          } else {
            const delay = t => new Promise(resolve => setTimeout(resolve, t));
            await delay(500);
            return await findDownloadButton();
          }
        })();
      } else if (window.location.href.search(/https:\/\/salescenter\.allegro\.com(?:\.allegrosandbox\.pl|)\/orders\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/) === 0) { 
        let delayedCheck = setTimeout(() => {
          const downloadButton = Array.from(document.querySelectorAll('button:enabled')).find(element => {
            if (element.textContent === 'DRUKUJ ETYKIETĘ' && Array.from(element.parentNode.parentNode.parentNode.parentNode.querySelectorAll('li')).find(element => element.innerText === 'Przesyłka polecona firmowa' || element.innerText === 'Przesyłka Polecona')) return true;
            return false;
          });
          if (downloadButton) {
            observer.disconnect();      
            downloadButton.addEventListener('click', downloadLabelButtonClick);
            downloadButton.style.backgroundColor = 'lightgreen'; 
            console.log('Znaleziono przycisk - timeout / 1');
          }
        }, 2000); 

        observer = new MutationObserver(mutations => {
          mutations.forEach(mutation => {
            if (mutation.type === 'childList' && mutation.target.nodeName === 'DIV') {
              mutation.addedNodes.forEach(node => {
                const downloadButton = Array.from(node.querySelectorAll('button:enabled')).find(element => {
                  if (element.textContent === 'DRUKUJ ETYKIETĘ' && Array.from(element.parentNode.parentNode.parentNode.parentNode.querySelectorAll('li')).find(element => element.innerText === 'Przesyłka polecona firmowa' || element.innerText === 'Przesyłka Polecona')) return true;
                  return false;
                });
                if (downloadButton) {
                  clearTimeout(delayedCheck);
                  observer.disconnect();
                  downloadButton.addEventListener('click', downloadLabelButtonClick);
                  downloadButton.style.backgroundColor = 'lightgreen'; 
                  console.log('Znaleziono przycisk - observer / 1');
                }
              });
            }
          });
        });
        const observedElement = document.querySelector('div[data-box-name="allegro.wza.order.details.packages"]');
        observer.observe(observedElement, { subtree: true, childList: true });
        
      } else if (window.location.href.search(/https:\/\/salescenter\.allegro\.com(?:\.allegrosandbox\.pl|)\/ship-with-allegro\/shipments/) === 0) {
        function findDownloadButton() {
          const shippingMethod = Array.from(document.querySelectorAll('p')).find(element => element.innerText === 'USŁUGI DODATKOWE')?.nextSibling?.innerText;
          if (shippingMethod) {
             observer.disconnect();
            if (['Mini Przesyłka', 'Allegro Mini Przesyłka', 'Allegro MiniPrzesyłka', 'Allegro Przesyłka polecona', 'Przesyłka Polecona'].indexOf(shippingMethod) === -1) return false;
          }
          let downloadButton = Array.from(document.querySelectorAll('button:enabled')).find(element => element.textContent === 'Etykiety');
          if (downloadButton) {
            observer.disconnect();
            downloadButton.addEventListener('click', downloadLabelButtonClick);
            downloadButton.style.backgroundColor = 'lightgreen'; 
            console.log('Znaleziono przycisk - timeout / 2');
            return true;
          }
          return false;
        };

        let delayedCheck = setTimeout(() => {
          findDownloadButton();
        }, 2000);
  
        const observer = new MutationObserver(mutations => {
          mutations.forEach(mutation => {
            if (mutation.type === 'childList' && mutation.target.nodeName === 'DIV') {
              mutation.addedNodes.forEach(node => {
                if (node.innerText.startsWith('Szczegóły przesyłki')) {
                  const shippingMethod = Array.from(document.querySelectorAll('p')).find(element => element.innerText === 'USŁUGI DODATKOWE')?.nextSibling?.innerText;
                  if (shippingMethod) {
                    observer.disconnect();
                    if (['Mini Przesyłka', 'Allegro Mini Przesyłka', 'Allegro MiniPrzesyłka', 'Allegro Przesyłka polecona', 'Przesyłka Polecona'].indexOf(shippingMethod) === -1) return;
                    clearTimeout(delayedCheck);
                    console.log('Znaleziono przycisk - observer / 2');

                    if (!findDownloadButton()) {
                      (async () => {
                        const delay = t => new Promise(resolve => setTimeout(resolve, t));
                        await delay(500);
                        findDownloadButton();
                      });
                    }
                  }	
                }
              })
            }
          });
        });
        observer.observe(document.body, { subtree: true, childList: true });
      }
    }
  });
  urlObserver.observe(document, {	subtree: true, childList: true });
});  

async function downloadLabelButtonClick() {
  let response;
  try {
    response = await sendMessage({ action: 'downloadLabel' });
    if (response.success === false) throw new Error(response.result);
  } catch (error) {
    console.log(`Błąd podczas pobierania etykiety. ${(error instanceof Error ? error.message : error)}`);
    return; 
  }

  if (response.result.filename !== undefined && response.result.id !== undefined) {
    try {
      await processPDF(response.result.filename, response.result.id);
    } catch (error) {
      alert(error instanceof Error ? error.message : error);
      return;
    }
  } else {
    alert('Błąd. Plik nie zostanie przetworzony.');
  }
}

async function processPDF(filename, id) {
  const { PDFDocument } = PDFLib;
  const url = chrome.runtime.getURL(filename);
  const arrayBuffer = await fetch(url).then(result => result.arrayBuffer()).catch(error => { return Promise.reject(`Błąd podczas ładowania etykiety. ${(error instanceof Error ? error.message : error)}`) });
  const pdfDoc = await PDFDocument.load(arrayBuffer);
  let pdfDocPages = pdfDoc.getPages();
  const { width, height } = pdfDocPages[0].getSize();
  const newPage = pdfDoc.addPage();
  newPage.setSize(width, height);
  pdfDocPages = pdfDoc.getPages();
  if (pdfDocPages.length > 2) return Promise.reject('Obsługiwane są tylko pliki zawierające jedną stronę! Plik nie zostanie przetworzony.');
  await sendMessage({ action: 'removeLabel', downloadItemId: id }).catch(error => { return Promise.reject(error) });
  const pdfDocCopy = await pdfDoc.copy();
  const pdfDocCopyPages = pdfDocCopy.getPages();
  const page = pdfDocCopyPages[0];

  const upperPartCoordinates = { x: 150, y: 0, width: (width - 150), height: height };
  const rSignCoordinates = { x: 130, y: 172, width: 18, height: 18 };
  const barcodeCoordinates = { x: 130, y: 35, width: 18, height: 130 };
  const lowerPartCoordinates = { x: 0, y: 0, width: 130, height: height };

  let embeddedPages = await pdfDoc.embedPages([page, page, page, page], [
    { left: upperPartCoordinates.x, right: upperPartCoordinates.x + upperPartCoordinates.height, bottom: upperPartCoordinates.y, top: upperPartCoordinates.y + upperPartCoordinates.height }, 
    { left: rSignCoordinates.x, right: rSignCoordinates.x + rSignCoordinates.width, bottom: rSignCoordinates.y, top: rSignCoordinates.y + rSignCoordinates.height }, 
    { left: barcodeCoordinates.x, right: barcodeCoordinates.x + barcodeCoordinates.width, bottom: barcodeCoordinates.y, top: barcodeCoordinates.y + barcodeCoordinates.height }, 
    { left: lowerPartCoordinates.x, right: lowerPartCoordinates.x + lowerPartCoordinates.width, bottom: lowerPartCoordinates.y, top: lowerPartCoordinates.y + lowerPartCoordinates.height }
  ]);

  pdfDocPages[1].drawPage(embeddedPages[0], {
    x: upperPartCoordinates.x,
    y: upperPartCoordinates.y,
    blendMode: 'Normal',
    opacity: 1
  });
  
  pdfDocPages[1].drawPage(embeddedPages[1], {
    x: rSignCoordinates.x,
    y: rSignCoordinates.y + barcodeCoordinates.height,
    blendMode: 'Normal',
    opacity: 1
  });

  pdfDocPages[1].drawPage(embeddedPages[2], {
    x: barcodeCoordinates.x - 2,
    y: barcodeCoordinates.y - 2,
    xScale: 1.2,
    yScale: 2,
    blendMode: 'Normal',
    opacity: 1
  });

  pdfDocPages[1].drawPage(embeddedPages[3], {
    x: lowerPartCoordinates.x,
    y: lowerPartCoordinates.y,
    blendMode: 'Normal',
    opacity: 1
  });

  pdfDoc.removePage(0);

  const pdfBytes = await pdfDoc.saveAsBase64({ dataUri: true });
  let downloadLink = document.createElement('a');
  downloadLink.href = pdfBytes;
  downloadLink.download = filename.slice(filename.lastIndexOf('/') + 1 );
  downloadLink.click();
  return Promise.resolve(true);
};