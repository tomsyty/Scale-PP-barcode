if (document.getElementById('pdfLibScript') === null) {
  var s = document.createElement('script');
  s.id = 'pdfLibScript';
  s.src = chrome.runtime.getURL('pdf-lib.js');
  (document.head||document.documentElement).appendChild(s);
  s.onload = function() {
    s.remove();
  };
}

window.addEventListener('load', () => {
  console.log('*** content script load event fired'); 
  let previousUrl = '';
  let observer;
  const urlObserver = new MutationObserver(() => {
    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
      if (observer !== undefined) {
        observer.disconnect();
        observer = undefined;
      }
      if (window.location.href.search(/https:\/\/allegro.pl(?:.allegrosandbox.pl|)\/moje-allegro\/sprzedaz\/zamowienia\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/) === 0) {       
        observer = new MutationObserver(mutations => {
          mutations.forEach(mutation => {
            if (mutation.type === 'childList' && mutation.target.nodeName === 'DIV') {
              mutation.addedNodes.forEach(node => {
                const downloadButton = Array.from(node.querySelectorAll('button:enabled')).find(element => {
                  if (element.textContent === 'DRUKUJ ETYKIETĘ' && Array.from(element.parentNode.parentNode.parentNode.parentNode.querySelectorAll('li')).find(element => element.innerText === 'Przesyłka polecona firmowa')) return true;
                  return false;
                });
                if (downloadButton) {
                  downloadButton.addEventListener('click', downloadLabelButtonClick);
                  downloadButton.style.backgroundColor = 'lightgreen'; 
                }
              });
            }
          });
        });
        const observedElement = document.querySelector('div[data-box-name="allegro.wza.order.details.packages"]');
        observer.observe(observedElement, {subtree: true, childList: true});
        return;
      }
    }
  });
  urlObserver.observe(document, {	subtree: true, childList: true });
  
  if (window.location.href.search(/https:\/\/allegro.pl(?:.allegrosandbox.pl|)\/moje-allegro\/sprzedaz\/wysylam\/wza\/nadaj-paczke-status/) === 0) {
    (function findDownloadButton() {
      let downloadButton = Array.from(document.querySelectorAll('button:enabled')).find(element => element.textContent === 'Pobierz etykiety');
      if (downloadButton !== undefined) {
        const shippingMethodCell = Array.from(document.querySelectorAll('th')).find(element => element.innerText === 'Metoda dostawy');
        if (shippingMethodCell !== undefined) {
          const shippingMethod = shippingMethodCell?.parentNode?.parentNode?.nextElementSibling?.firstChild?.childNodes?.[shippingMethodCell.cellIndex]?.innerText;
          if (['Allegro Mini Przesyłka', 'Allegro Przesyłka polecona'].indexOf(shippingMethod) === -1) return;
          downloadButton.addEventListener('click', downloadLabelButtonClick);
          downloadButton.style.backgroundColor = 'lightgreen';
        }
      } else {
        const delay = t => new Promise(resolve => setTimeout(resolve, t));
        delay(500).then(() => {
          findDownloadButton();
          return;
        });
      }
    })();
  } else if (window.location.href.search(/https:\/\/allegro.pl(?:.allegrosandbox.pl|)\/moje-allegro\/sprzedaz\/wysylam\/lista-przesylek/) === 0) {
    const observer = new MutationObserver(mutations => {
			mutations.forEach(mutation => {
        if (mutation.type === 'childList' && mutation.target.nodeName === 'DIV') {
          mutation.addedNodes.forEach(node => {
            if (node.innerText.startsWith('Szczegóły przesyłki')) {
              const shippingMethod = Array.from(document.querySelectorAll('span')).find(element => element.innerText === 'Usługi dodatkowe')?.parentNode?.nextSibling?.firstChild?.innerText;
              if (shippingMethod) {
                if (['Przesyłka polecona firmowa'].indexOf(shippingMethod) === -1) return;
                (function findDownloadButton() {
                  let downloadButton = Array.from(document.querySelectorAll('button:enabled')).filter(element => element.textContent === 'Etykiety');
                  if (downloadButton.length === 2) {
                    downloadButton = downloadButton[1];
                    downloadButton.addEventListener('click', downloadLabelButtonClick);
                    downloadButton.parentNode.parentNode.style.backgroundColor = 'lightgreen'; 
                  } else {
                    const delay = t => new Promise(resolve => setTimeout(resolve, t));
                    delay(500).then(() => {
                      findDownloadButton();
                      return;
                    });
                  }
                })();
              }	
            }
          })
        }
			});
		});
		observer.observe(document.body, {subtree: true, childList: true});
  }
});  

function downloadLabelButtonClick() {
  chrome.runtime.sendMessage({action: 'downloadLabel'}).then(response => {
    if (response.filename && response.id) {
      processPDF(response.filename, response.id).catch(error => {
        alert(error);
        return;
      });
    } else {
      alert('Błąd. Plik nie zostanie przetworzony.');
    }
  }).catch(error => {
    alert(`${(error.name !== 'customError' ? 'Błąd podczas pobierania etykiety, szczegóły (oryginalna treść wiadomości): ' : '')}${error.message}`); 
    return;
  });
}

async function processPDF(filename, id) {
  const { PDFDocument } = PDFLib;
  const url = chrome.runtime.getURL(filename);
  const arrayBuffer = await fetch(url).then(result => result.arrayBuffer()).catch(error => { return Promise.reject(`Błąd podczas ładowania etykiety, szczegóły (oryginalna treść wiadomości): ${error.message}`) });
  const pdfDoc = await PDFDocument.load(arrayBuffer);
  let pdfDocPages = pdfDoc.getPages();
  const { width, height } = pdfDocPages[0].getSize();
  const newPage = pdfDoc.addPage();
  newPage.setSize(width, height);
  pdfDocPages = pdfDoc.getPages();
  if (pdfDocPages.length > 2) return Promise.reject('Obsługiwane są tylko pliki zawierające jedną stronę! Plik nie zostanie przetworzony.');
  await chrome.runtime.sendMessage({action: 'removeLabel', downloadItemId: id}).catch(error => { return Promise.reject(`${(error.name !== 'customError' ? 'Błąd podczas usuwania etykiety, szczegóły (oryginalna treść wiadomości): ' : '')}${error.message}`) });
  const pdfDocCopy = await pdfDoc.copy();
  const pdfDocCopyPages = pdfDocCopy.getPages();
  const page = pdfDocCopyPages[0];
  const upperPartCoordinates = { x: 156, y: 0, width: (width - 156), height: height };
  const rSignCoordinates = { x: 130, y: 170, width: 25, height: 25 };
  const barcodeCoordinates = { x: 130, y: 35, width: 22, height: 130 };
  const lowerPartCoordinates = { x: 0, y: 0, width: 130, height: height };

  let embeddedPages = await pdfDoc.embedPages([page, page, page, page], [
    { left: upperPartCoordinates.x, right: upperPartCoordinates.x + upperPartCoordinates.height, bottom: upperPartCoordinates.y, top: upperPartCoordinates.y + upperPartCoordinates.height }, 
    { left: rSignCoordinates.x, right: rSignCoordinates.x + rSignCoordinates.width, bottom: rSignCoordinates.y, top: rSignCoordinates.y + rSignCoordinates.height }, 
    { left: barcodeCoordinates.x, right: barcodeCoordinates.x + barcodeCoordinates.width, bottom: barcodeCoordinates.y, top: barcodeCoordinates.y + barcodeCoordinates.height }, 
    { left: lowerPartCoordinates.x, right: lowerPartCoordinates.x + lowerPartCoordinates.width, bottom: lowerPartCoordinates.y, top: lowerPartCoordinates.y + lowerPartCoordinates.height }
  ]);

  pdfDocPages[1].drawPage(embeddedPages[0], {
    x: upperPartCoordinates.x,
    y: upperPartCoordinates.y,
    blendMode: 'Normal',
    opacity: 1
  });
  
  pdfDocPages[1].drawPage(embeddedPages[1], {
    x: rSignCoordinates.x,
    y: rSignCoordinates.y + barcodeCoordinates.height,
    blendMode: 'Normal',
    opacity: 1
  });

  pdfDocPages[1].drawPage(embeddedPages[2], {
    x: barcodeCoordinates.x - 2,
    y: barcodeCoordinates.y - 2,
    xScale: 1.2,
    yScale: 2,
    blendMode: 'Normal',
    opacity: 1
  });

  pdfDocPages[1].drawPage(embeddedPages[3], {
    x: lowerPartCoordinates.x,
    y: lowerPartCoordinates.y,
    blendMode: 'Normal',
    opacity: 1
  });

  pdfDoc.removePage(0);

  const pdfBytes = await pdfDoc.saveAsBase64({ dataUri: true });
  let downloadLink = document.createElement('a');
  downloadLink.href = pdfBytes;
  downloadLink.download = filename.slice(filename.lastIndexOf('/') + 1 );
  downloadLink.click();
  return Promise.resolve(true);
};